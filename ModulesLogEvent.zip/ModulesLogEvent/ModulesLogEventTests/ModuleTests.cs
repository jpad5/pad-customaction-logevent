using Microsoft.PowerPlatform.PowerAutomate.Desktop.Actions.SDK.Tests;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;

namespace ModulesLogEventTests
{
    [TestClass]
    public class ModuleTests
    {
        [TestMethod]
        public void Module_IsValid()
        {

            //C:\Users\Jay Padimiti\source\repos\Modules.LogEvent\Modules.LogEvent\bin\Debug
            string moduleDllPath = "C:\\Users\\Jay Padimiti\\source\\repos\\ModulesLogEvent\\ModulesLogEvent\\bin\\Debug\\Modules.LogEvent.dll";
        //TODO: Set correct dll path
            bool isValid = ModuleValidator.IsValid(moduleDllPath, out var errors);

            Assert.IsTrue(isValid, $"Module is invalid. Validation Errors: {Environment.NewLine}{string.Join(Environment.NewLine, errors)}");
        }
    }
}
