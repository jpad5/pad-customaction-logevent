using Microsoft.PowerPlatform.PowerAutomate.Desktop.Actions.SDK.Tests;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModulesLogEvent;
using System;

namespace Modules.LogEvent.Tests
{
    [TestClass]
    public class Action1Tests
    {
        [TestMethod]
        public void Action_IsValid()
        {
            bool isValid = ActionValidator.IsValid(typeof(LogEventToFile), out var errors);

            Assert.IsTrue(isValid, $"Action is invalid. Validation Errors: {Environment.NewLine}{string.Join(Environment.NewLine, errors)}");
        }

        [TestMethod]
        public void Action_Execute_Success()
        {
            try
            {
                LogEventToFile action = new LogEventToFile() { LogFileName = "C:\\RPA\\padca.txt", LogMessage = "Test Message" };
                action.Execute(null);
                var actionOutput = action.StatusCode;
            }
            catch (Exception e)
            {
                Assert.Fail("Expected no exception, but got: " + e.Message);
            }
        }
    }
}
