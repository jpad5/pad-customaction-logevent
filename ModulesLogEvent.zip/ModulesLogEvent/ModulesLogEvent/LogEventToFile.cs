﻿using System;
using System.IO;
using Microsoft.PowerPlatform.PowerAutomate.Desktop.Actions.SDK;
using Microsoft.PowerPlatform.PowerAutomate.Desktop.Actions.SDK.Attributes;

namespace ModulesLogEvent
{
    [Action(Id = "LogEventToFile" , Order = 1, Category = "Logging")]
    [Throws("LogEventError")]
    public class LogEventToFile : ActionBase
    { 
        [InputArgument]
        public string LogFileName { get; set; }

        [InputArgument]
        public string LogMessage { get; set; }

        [OutputArgument]
        public bool StatusCode { get; set; }
    
        public override void Execute(ActionContext context)
        {
            try
            {
                //TODO: add action execution code here
                //if (File.Exists(LogFileName))
                //{
                    // To append all of the text to the file
                    File.AppendAllText(LogFileName, LogMessage);
                    StatusCode = true;
                //}
            }
            catch (Exception e)
            {
                if (e is ActionException) throw;

                throw new ActionException("LogEventError", e.Message, e.InnerException);
            }
        }
    }
}